package com.example.cuestionariosteven2damb

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val botonIngresar = findViewById<Button>(R.id.ingresar)
        val botonBorrar = findViewById<Button>(R.id.delete)
        val botonSing = findViewById<Button>(R.id.signin)
        val userInsert = findViewById<EditText>(R.id.user)
        val passInsert = findViewById<EditText>(R.id.password)
        val admin = AdminSQLiteOpenHelper(this,"administracion", null, 1)
        val bd = admin.writableDatabase
        val registro = ContentValues()
        //Primer usuario y contraseña
        registro.put("user", "Paco")
        registro.put("password", "1234")
        bd.insert("sesion", null, registro)
        bd.close()


        // Botón Ingresar a MainActivity
        botonIngresar.setOnClickListener {
            val usuario = userInsert.text.toString()
            val pasword = passInsert.text.toString()
            if (usuario.isNotEmpty() && pasword.isNotEmpty()) {
                val bd = admin.writableDatabase
                val fila = bd.rawQuery("select user, password from sesion where user = ? and password = ?", arrayOf(usuario, pasword))
                if (fila.moveToFirst()) {
                    val intent = Intent(this, inicio::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                }
                fila.close()
                bd.close()
            } else {
                Toast.makeText(this, "Usuario y Contraseña obligatorios", Toast.LENGTH_SHORT).show()
            }
        }
        // Botón Borrar usuario y contraseña
        botonBorrar.setOnClickListener {
            val usuario = userInsert.text.toString()
            val pasword = passInsert.text.toString()

            if (usuario.isNotEmpty() && pasword.isNotEmpty()) {
                val bd = admin.writableDatabase

                // Elimina el usuario que coincida con el nombre y la contraseña
                val deletedRows = bd.delete("sesion", "user = ? AND password = ?", arrayOf(usuario, pasword))

                bd.close()

                if (deletedRows > 0) {
                    Toast.makeText(this, "Usuario borrado exitosamente", Toast.LENGTH_SHORT).show()
                    userInsert.text.clear()
                    passInsert.text.clear()
                } else {
                    Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Usuario y contraseña son obligatorios para borrar", Toast.LENGTH_SHORT).show()
            }
        }

        botonSing.setOnClickListener {
            val usuario = userInsert.text.toString()
            val pasword = passInsert.text.toString()

            if (usuario.isNotEmpty() && pasword.isNotEmpty()) {
                val bd = admin.writableDatabase

                val registro = ContentValues().apply {
                    put("user", usuario)
                    put("password", pasword)
                }

                // Insertar el nuevo usuario en la base de datos
                val resultado = bd.insert("sesion", null, registro)
                bd.close()

                if (resultado != -1L) {
                    // Si la inserción fue exitosa, resultado devuelve el ID de la fila insertada
                    Toast.makeText(this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show()
                } else {
                    // Si la inserción falló, resultado devuelve -1
                    Toast.makeText(this, "Error al registrar usuario", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Usuario y contraseña son obligatorios para registrar", Toast.LENGTH_SHORT).show()
            }
        }

    }
}
