package com.example.cuestionariosteven2damb

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog

class preguntas : AppCompatActivity() {

    private lateinit var textPregunta: TextView
    private lateinit var radioGroup: RadioGroup
    private lateinit var btnSiguiente: Button
    private lateinit var adminBD: AdminSQLiteOpenHelper
    private lateinit var db: SQLiteDatabase

    private var preguntaActual = 0
    private var idCuestionario = 0
    private var dificultad = ""
    private var preguntas = mutableListOf<Map<String, String>>()
    private var puntos = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preguntas)

        // Obtener el id del cuestionario y dificultad seleccionada
        idCuestionario = intent.getIntExtra("id_cuestionario", 0)
        dificultad = intent.getStringExtra("dificultad") ?: ""

        // Inicializar las vistas
        textPregunta = findViewById(R.id.textPregunta)
        radioGroup = findViewById(R.id.radioGroup)
        btnSiguiente = findViewById(R.id.btnSiguiente)

        // Cargar las preguntas del cuestionario
        cargarPreguntas()

        // Configurar el botón "Siguiente"
        btnSiguiente.setOnClickListener {
            verificarRespuesta()
            if (preguntaActual < preguntas.size) {
                cargarPregunta()
            } else {
                mostrarResultado()
            }
        }
    }

    // Función para cargar las preguntas desde la base de datos según el cuestionario y dificultad
    private fun cargarPreguntas() {
        adminBD = AdminSQLiteOpenHelper(this, "cuestionariosDB", null, 1)
        db = adminBD.readableDatabase

        val cursor = db.rawQuery(
            "SELECT pregunta, opcion1, opcion2, opcion3, opcion4, correcta FROM preguntas WHERE id_cuestionario = ? AND dificultad = ?",
            arrayOf(idCuestionario.toString(), dificultad)
        )

        // Verificamos si la consulta devuelve algún resultado
        if (cursor.moveToFirst()) {
            do {
                // Verificamos que los índices de las columnas sean válidos
                val preguntaIndex = cursor.getColumnIndex("pregunta")
                val opcion1Index = cursor.getColumnIndex("opcion1")
                val opcion2Index = cursor.getColumnIndex("opcion2")
                val opcion3Index = cursor.getColumnIndex("opcion3")
                val opcion4Index = cursor.getColumnIndex("opcion4")
                val correctaIndex = cursor.getColumnIndex("correcta")

                if (preguntaIndex == -1 || opcion1Index == -1 || opcion2Index == -1 || opcion3Index == -1 || opcion4Index == -1 || correctaIndex == -1) {
                    Log.e("BaseDeDatos", "Algunas columnas no existen en el cursor")
                    return  // Terminamos la ejecución si alguna columna no existe
                }

                // Si todos los índices son válidos, agregamos la pregunta a la lista
                val pregunta = mapOf(
                    "pregunta" to cursor.getString(preguntaIndex),
                    "opcion1" to cursor.getString(opcion1Index),
                    "opcion2" to cursor.getString(opcion2Index),
                    "opcion3" to cursor.getString(opcion3Index),
                    "opcion4" to cursor.getString(opcion4Index),
                    "correcta" to cursor.getString(correctaIndex)
                )
                preguntas.add(pregunta)

            } while (cursor.moveToNext())

            Log.d("BaseDeDatos", "Preguntas cargadas correctamente: ${preguntas.size} preguntas encontradas")
        } else {
            Log.e("BaseDeDatos", "No se encontraron preguntas para este cuestionario y dificultad")
        }

        cursor.close()
        db.close()

        // Verificamos si se han cargado preguntas
        if (preguntas.isEmpty()) {
            Log.e("BaseDeDatos", "La lista de preguntas está vacía. No se pueden cargar preguntas.")
            Toast.makeText(this, "No se encontraron preguntas para este cuestionario.", Toast.LENGTH_SHORT).show()
            return
        }

        // Aleatorizamos el orden de las preguntas
        preguntas.shuffle()

        // Cargar la primera pregunta
        cargarPregunta()
    }



    // Función para cargar una pregunta aleatoria
    private fun cargarPregunta() {
        if (preguntaActual < preguntas.size) {
            val pregunta = preguntas[preguntaActual]
            textPregunta.text = pregunta["pregunta"]
            radioGroup.removeAllViews()  // Esto elimina todas las opciones anteriores

            // Crear los RadioButtons para las opciones
            val opciones = listOf(
                pregunta["opcion1"],
                pregunta["opcion2"],
                pregunta["opcion3"],
                pregunta["opcion4"]
            ).shuffled()  // Aleatorizamos el orden de las opciones

            for (i in opciones.indices) {
                val radioButton = RadioButton(this).apply {
                    text = opciones[i]
                    id = i  // Asignamos un id único a cada opción
                }
                radioGroup.addView(radioButton)
            }
        } else {
            mostrarResultado()
        }
    }

    // Función para verificar la respuesta seleccionada
    private fun verificarRespuesta() {
        val pregunta = preguntas[preguntaActual]
        val seleccionada = radioGroup.checkedRadioButtonId
        if (seleccionada != -1) {
            val respuestaSeleccionada = findViewById<RadioButton>(seleccionada).text.toString()
            if (respuestaSeleccionada == pregunta["correcta"]) {
                puntos++
            }
            preguntaActual++
        } else {
            Toast.makeText(this, "Selecciona una opción", Toast.LENGTH_SHORT).show()
        }
    }

    // Función para mostrar el resultado final
    private fun mostrarResultado() {
        AlertDialog.Builder(this)
            .setTitle("Cuestionario finalizado")
            .setPositiveButton("Aceptar") { _, _ ->
                // Guardar la puntuación final
                Resultados.nota = puntos.toDouble()

                // Redirigir a la actividad de resultados
                val intent = Intent(this, resultado::class.java)
                startActivity(intent)
                finish()
            }
            .show()
    }
}
