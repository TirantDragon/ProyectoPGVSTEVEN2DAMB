package com.example.cuestionariosteven2damb

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class inicio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio)

        // Configurar los botones
        findViewById<Button>(R.id.btn_cuest).setOnClickListener {
            val intent = Intent(this, cuestionarios::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btn_perfil).setOnClickListener {
            val intent = Intent(this, perfil::class.java)
            startActivity(intent)
        }
    }
}
