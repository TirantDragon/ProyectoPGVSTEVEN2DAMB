package com.example.cuestionariosteven2damb

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class resultado : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        val resultado = findViewById<TextView>(R.id.resultado)
        val finButton = findViewById<Button>(R.id.fin)

        val puntos = intent.getIntExtra("puntos", 0)
        resultado.text = "Tu nota es: $puntos/10"

        finButton.setOnClickListener {
            // Regresar al inicio
            val intent = Intent(this, inicio::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish() // Finalizar la actividad actual
        }
    }
}
