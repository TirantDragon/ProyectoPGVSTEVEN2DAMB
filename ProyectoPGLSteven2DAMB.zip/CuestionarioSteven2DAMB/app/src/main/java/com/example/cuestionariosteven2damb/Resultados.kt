package com.example.cuestionariosteven2damb

import androidx.appcompat.app.AppCompatActivity

object Resultados : AppCompatActivity() {
    var nota: Double = 0.0
}
