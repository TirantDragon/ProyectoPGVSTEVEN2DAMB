package com.example.cuestionariosteven2damb

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.database.sqlite.SQLiteDatabase

class perfil : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        // Obtener la referencia de los TextViews donde mostraremos los datos
        val tvUsername: TextView = findViewById(R.id.tvUsername)
        val tvPuntuacion: TextView = findViewById(R.id.tvPuntuacion)

        // Obtener el código de sesión
        val codigoSesion = obtenerCodigoSesion()

        // Si hay código de sesión válido, recuperar los datos del usuario
        if (codigoSesion != null) {
            // Instancia de la base de datos
            val adminBD = AdminSQLiteOpenHelper(this, "cuestionariosDB", null, 1)
            val db = adminBD.readableDatabase

            // Consultar el usuario con el código de sesión
            val cursor = db.rawQuery("SELECT user, puntuacion FROM sesion WHERE codigo = ?", arrayOf(codigoSesion.toString()))

            if (cursor.moveToFirst()) {
                // Obtener el nombre de usuario y la puntuación
                val nombreUsuario = cursor.getString(cursor.getColumnIndexOrThrow("user"))
                val puntuacion = cursor.getInt(cursor.getColumnIndexOrThrow("puntuacion"))

                // Mostrar la información en los TextViews
                tvUsername.text = "Nombre de usuario: $nombreUsuario"
                tvPuntuacion.text = "Puntuación: $puntuacion"
            } else {
                // En caso de que no se encuentren datos, mostrar un mensaje
                tvUsername.text = "Nombre de usuario: No encontrado"
                tvPuntuacion.text = "Puntuación: 0"
            }

            cursor.close()
            db.close()
        } else {
            // Si no hay sesión activa, mostrar un mensaje de error
            tvUsername.text = "No hay sesión activa."
            tvPuntuacion.text = "Puntuación: N/A"
        }
    }

    // Este método simula obtener el código de sesión del usuario registrado.
    private fun obtenerCodigoSesion(): Int? {
        return 1 // Cambia este valor por el código del usuario actual registrado.
    }
}
