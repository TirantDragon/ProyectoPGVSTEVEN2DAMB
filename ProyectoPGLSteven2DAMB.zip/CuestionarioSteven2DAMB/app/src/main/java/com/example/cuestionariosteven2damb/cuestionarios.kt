package com.example.cuestionariosteven2damb

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class cuestionarios : AppCompatActivity() {

    private lateinit var layoutCuest: LinearLayout
    private lateinit var btnAnyadir: Button
    private lateinit var btnEliminarDatos: Button
    private lateinit var btnMostrarPreguntas: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cuestionarios)

        layoutCuest = findViewById(R.id.linearLayoutCuestionarios)
        btnAnyadir = findViewById(R.id.btn_añadir)
        btnEliminarDatos = findViewById(R.id.btn_eliminar)

        cargarCuestionarios() // Cargar los cuestionarios desde la base de datos

        btnAnyadir.setOnClickListener { cargarArchivoSQL() } // Llamar a la función para cargar archivo SQL

        btnEliminarDatos.setOnClickListener { eliminarDatosTabla("cuestionario") } // Eliminar datos de la tabla "cuestionario"

        // Botón para mostrar todas las preguntas
        btnMostrarPreguntas = Button(this).apply {
            text = "Mostrar todas las preguntas"
            setOnClickListener { mostrarPreguntas() } // Mostrar preguntas al hacer clic
        }
        layoutCuest.addView(btnMostrarPreguntas) // Añadir el botón de preguntas a la vista
    }

    private fun eliminarDatosTabla(nombreTabla: String) {
        val adminBD = AdminSQLiteOpenHelper(this, "cuestionariosDB", null, 1)
        val db = adminBD.writableDatabase

        try {
            val filasAfectadas = db.delete(nombreTabla, null, null) // Eliminar todos los registros de la tabla
            db.close()

            // Mostrar mensaje de confirmación
            if (filasAfectadas > 0) {
                Toast.makeText(this, "Datos eliminados de la tabla $nombreTabla.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "La tabla $nombreTabla ya está vacía.", Toast.LENGTH_SHORT).show()
            }

            cargarCuestionarios() // Recargar los cuestionarios tras eliminar datos

        } catch (e: Exception) {
            // Mostrar error si falla la eliminación
            Toast.makeText(this, "Error al eliminar datos: ${e.message}", Toast.LENGTH_LONG).show()
            Log.e("EliminarDatos", "Error eliminando datos de la tabla $nombreTabla", e)
        }
    }

    private fun cargarCuestionarios() {
        val adminBD = AdminSQLiteOpenHelper(this, "cuestionariosDB", null, 1)
        val db = adminBD.readableDatabase

        val cursor = db.rawQuery("SELECT id_cuestionario, nombre FROM cuestionario", null)

        if (cursor.moveToFirst()) {
            layoutCuest.removeAllViews() // Limpiar la vista antes de cargar los nuevos cuestionarios
            do {
                val idCuestionario = cursor.getInt(cursor.getColumnIndexOrThrow("id_cuestionario"))
                val nombreCuestionario = cursor.getString(cursor.getColumnIndexOrThrow("nombre"))

                val boton = Button(this).apply {
                    text = nombreCuestionario
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setOnClickListener {
                        abrirCuestionario(idCuestionario, nombreCuestionario) // Abrir el cuestionario al hacer clic
                    }
                }
                layoutCuest.addView(boton) // Añadir el botón a la vista
            } while (cursor.moveToNext())
        } else {
            Toast.makeText(this, "No hay cuestionarios disponibles.", Toast.LENGTH_SHORT).show() // Si no hay cuestionarios
        }

        cursor.close()
        db.close()
    }

    private fun cargarArchivoSQL() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "text/*" // Solo seleccionar archivos de texto
        }
        startActivityForResult(Intent.createChooser(intent, "Selecciona un archivo SQL"), 1) // Iniciar el selector de archivos
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            val uri = data?.data
            if (uri != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val inputStream = contentResolver.openInputStream(uri) // Abrir archivo
                        val reader = inputStream?.bufferedReader()
                        val sqlBuilder = StringBuilder()

                        reader?.useLines { lines ->
                            lines.forEach { line -> sqlBuilder.append(line).append("\n") } // Leer el archivo línea por línea
                        }

                        val sqlContent = sqlBuilder.toString()

                        if (sqlContent.isEmpty()) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@cuestionarios, "Archivo vacío o no válido.", Toast.LENGTH_LONG).show()
                            }
                            return@launch
                        }

                        val adminBD = AdminSQLiteOpenHelper(this@cuestionarios, "cuestionariosDB", null, 1)
                        val db = adminBD.writableDatabase

                        val sqlStatements = sqlContent.split(";") // Dividir por sentencias SQL
                        sqlStatements.forEach { statement ->
                            val cleanStatement = statement.trim()
                            if (cleanStatement.isNotEmpty()) {
                                try {
                                    db.execSQL(cleanStatement) // Ejecutar cada sentencia SQL
                                } catch (sqlEx: Exception) {
                                    Log.e("SQLExecution", "Error al ejecutar sentencia: $cleanStatement", sqlEx)
                                }
                            }
                        }

                        withContext(Dispatchers.Main) {
                            cargarCuestionarios() // Recargar los cuestionarios después de cargar el archivo
                        }
                    } catch (e: Exception) {
                        Log.e("FileProcessing", "Error al procesar el archivo SQL", e)
                        withContext(Dispatchers.Main) {
                            Toast.makeText(this@cuestionarios, "Error al cargar el archivo: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }

    private fun mostrarPreguntas() {
        val adminBD = AdminSQLiteOpenHelper(this, "cuestionariosDB", null, 1)
        val db = adminBD.readableDatabase

        val cursor = db.rawQuery("SELECT * FROM preguntas", null)

        val datos = StringBuilder()
        if (cursor.moveToFirst()) {
            do {
                try {
                    val idPregunta = cursor.getInt(cursor.getColumnIndexOrThrow("id_pregunta"))
                    val textoPregunta = cursor.getString(cursor.getColumnIndexOrThrow("pregunta"))
                    datos.append("ID: $idPregunta - Pregunta: $textoPregunta\n") // Añadir pregunta a los datos
                } catch (e: Exception) {
                    Log.e("CursorError", "Error al obtener los datos del cursor", e)
                }
            } while (cursor.moveToNext())
        } else {
            datos.append("No hay preguntas disponibles.") // Si no hay preguntas
        }

        cursor.close()
        db.close()

        val scrollView = ScrollView(this)
        val textView = TextView(this).apply {
            text = datos.toString()
            textSize = 16f
            setPadding(16, 16, 16, 16)
        }
        scrollView.addView(textView)

        AlertDialog.Builder(this)
            .setTitle("Lista de Preguntas")
            .setView(scrollView)
            .setPositiveButton("Cerrar") { dialog, _ -> dialog.dismiss() } // Botón para cerrar
            .create()
            .show()
    }

    private fun abrirCuestionario(idCuestionario: Int, nombre: String) {
        AlertDialog.Builder(this)
            .setTitle("Seleccionar Cuestionario")
            .setMessage("¿Quieres abrir el cuestionario '$nombre'?")
            .setPositiveButton("Sí") { _, _ ->
                val intent = Intent(this, preguntas::class.java).apply {
                    putExtra("id_cuestionario", idCuestionario) // Pasar ID y nombre del cuestionario
                    putExtra("nombre", nombre)
                }
                startActivity(intent) // Iniciar la actividad de preguntas
            }
            .setNegativeButton("No", null)
            .show()
    }
}
